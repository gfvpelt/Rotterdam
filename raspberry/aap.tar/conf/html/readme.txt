Serve your own static html pages or resources from here.
Files stored in this folder will be available through the HTTP server of openHAB under 'http://<device-ip>:8080/static'.
Resources for sitemap elements (image, video,...) can also be provided though this folder.
