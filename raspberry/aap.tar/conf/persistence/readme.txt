Your persistence configuration goes here.
All persistence files have to have the ".persist" file extension and must follow a special syntax.

Check out the openHAB documentation for more details:
http://docs.openhab.org/features/persistence.html
